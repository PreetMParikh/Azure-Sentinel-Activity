import datetime
import logging
import time
import azure.functions as func

import base64

import hashlib
import hmac
import json

import math
import os
import requests
from queue import Queue
from threading import Thread
from .state_manager import StateManager

API_KEY = os.environ["ArmisSecretKey"]
url = os.environ["ArmisURL"]
connection_string = os.environ["AzureWebJobsStorage"]
customer_id = os.environ["WorkspaceID"]
shared_key = os.environ["WorkspaceKey"]
armis_activities = os.environ["ArmisActivitiesTableName"]

HTTP_ERRORS = {
    400: "Bad request: Missing aql Parameter.",
    401: "Authentication error: Authorization information is missing or invalid.",
}
ERROR_MESSAGES = {
    "ACCESS_TOKEN_NOT_FOUND": "Authentication Failed: Access Token not found. Please check Key.",
    "HOST_CONNECTION_ERROR": "Connection Failed: Invalid host while verifying 'Armis Account'. Please check domain.",
}


body = ""
result_queue = Queue(10)


class Armis:
    def __init__(self):
        """
        This method will initialize object of class
        """
        self._link = url
        self._header = {
            "Content-Type": "application/json",
        }
        self._secret_key = API_KEY
        self._result = []

    def _get_access_token(self, armis_link_suffix):
        """
        This method will fetch the access token using api and
        set it in header for further use

        Args:
            armis_link_suffix (String): This variable will be suffix/add-on to the link.
        """
        if self._secret_key is not None and self._link is not None:
            parameter = {"secret_key": self._secret_key}
            try:
                response = requests.post(
                    (self._link + armis_link_suffix), params=parameter
                )
                if response.status_code == 200:
                    _access_token = json.loads(response.text)["data"]["access_token"]
                    self._header.update({"Authorization": _access_token})
                elif response.status_code == 400:
                    logging.error("Bad request, please check the arguments you passed.")
                else:
                    logging.error(
                        "Something wrong. Error code: {}".format(response.status_code)
                    )
            except Exception as err:
                logging.error(f"Access Token getting failed. Exiting program. {err}")
                exit()
        else:
            logging.error("The secret key or link has not been initialized")
            exit()

    def _get_data(self, armis_link_suffix, parameter, table_name, state):
        """_get_data is used to get data using api.

        Args:
            self: Armis object.
            armis_link_suffix (String): will be containing the other part of link.
            parameter (json): will contain the json data to sends to parameter to get data from REST API.
            azuresentinel (object): AzureSentinel object.
            table_name (String): table name to store the data in azure sentinel.
            state (object): StateManager object.

        """
        try:
            current_time = datetime.datetime.utcnow()
            response = requests.get(
                (self._link + armis_link_suffix), params=parameter, headers=self._header
            )
            if response.status_code == 200:
                data = json.loads(response.text)["data"]["results"]
                body = json.dumps(data, indent=2)
                queue_item = {
                    "table_name": table_name,
                    "state": state,
                    "body": body,
                    "current_time": current_time,
                }
                result_queue.put(queue_item)
            elif response.status_code == 400:
                logging.error(HTTP_ERRORS[400])
            elif response.status_code == 401:
                logging.error(
                    HTTP_ERRORS[401] + str("inside _get_data") + str(response.text)
                )
            else:
                logging.error(
                    "Something wrong. Error code: {}".format(response.status_code)
                )
        except requests.exceptions.ConnectionError:
            logging.error(ERROR_MESSAGES["HOST_CONNECTION_ERROR"])
        except requests.exceptions.RequestException as request_err:
            logging.error(request_err)
        except Exception as err:
            logging.error(f"Data getting failed. {err}")

    def _get_links(self, armis_link_suffix, parameter, in_count):
        """_get_links is used to create links so that we can divide the data into multiple parts.

        Args:
            self: Armis object.
            armis_link_suffix (String): will be containing the other part of link.
            parameter (json): will contain the json data to create links.
            in_count (int): will contain the total number of records.

        """
        try:

            response = requests.get(
                (self._link + armis_link_suffix),
                params=parameter,
                headers=self._header,
            )
            if response.status_code == 200:
                try:
                    total_data = math.ceil(
                        (json.loads(response.text)["data"]["total"]) / in_count
                    )
                    from_location = 0
                    length = in_count
                    frame = {}
                    while total_data:

                        frame[total_data] = {
                            "aql": parameter["aql"],
                            "from": from_location,
                            "length": length,
                            "fields": parameter["fields"],
                        }
                        from_location += length
                        total_data -= 1
                    return frame
                except Exception as elt:
                    logging.error(elt)
            elif response.status_code == 400:
                logging.error(HTTP_ERRORS[400])
            elif response.status_code == 401:
                logging.error(
                    HTTP_ERRORS[401] + str("inside _get_links") + str(response.text)
                )
            else:
                logging.error(
                    "Something wrong. Error code: {}".format(response.status_code)
                )
        except requests.exceptions.ConnectionError:
            logging.error(ERROR_MESSAGES["HOST_CONNECTION_ERROR"])
        except requests.exceptions.RequestException as request_err:
            logging.error(request_err)
        except Exception as err:
            logging.error(f"Data getting failed. {err}")

    def _data_table_not_exist(self, type_data):
        """_data_table_not_exist is used to push all the data into table.

        Args:
            self: Armis object.
            type_data (json): will contain the json data to use in the _get_links function.
            state (object): StateManager object.
            table_name (String): table name to store the data in azure sentinel.

        """
        try:

            self._get_access_token("/access_token/")
            links = self._get_links(
                "/search/",
                type_data,
                1000,
            )
            return links
        except Exception as elt:
            logging.error(
                "Error while creating table in azure sentinel: {}".format(elt)
            )

    def _data_table_exist(self, type_data, last_time):
        """_data_table_exist is used to push updated data into table.

        Args:
            self: Armis object.
            type_data (json): will contain the json data to use in the _get_links function.
            state (object): StateManager object.
            last_time (String): will contain the timestamp.
            table_name (String): table name to store the data in azure sentinel.

        """
        try:
            time_frame = datetime.datetime.utcnow() - datetime.datetime.strptime(
                last_time, "%Y-%m-%d %H:%M:%S.%f"
            )
            logging.info("time_frame : {}".format(time_frame))
            PER_DAY_SECONDS = 86400
            NO_OF_SECONDS_ALLOWED = 7776000
            days, seconds = time_frame.days, time_frame.seconds
            total_seconds = days * PER_DAY_SECONDS + seconds + 2
            if total_seconds > NO_OF_SECONDS_ALLOWED:
                total_seconds = NO_OF_SECONDS_ALLOWED
            total_seconds -= 1
            self._get_access_token("/access_token/")
            aql_data = """{} timeFrame:"{} Seconds" """.format(
                type_data["aql"], total_seconds
            )
            type_data["aql"] = aql_data
            links = self._get_links("/search/", type_data, 1000)
            if len(links) > 0:
                return links
        except Exception as error:
            logging.error(error)

    def fetch_data(self, list_data):
        links = list_data["links"]
        for link in links:
            self._get_data(
                "/search/",
                links[link],
                list_data["armis_activities"],
                list_data["state_activities"],
            )
            self._result = []

    def check_data_exists_or_not(self):
        """check_data_exists_or_not is to check if the data is exists or not using the timestamp file.

        Args:
            self: Armis object.

        """
        parameter_activity = {
            "aql": "in:activity",
            "fields": "title,type,time,site,sensor,protocol,content,activityUUID",
        }
        state_activities = StateManager(
            connection_string=connection_string, file_path="funcarmisactivitiesfile"
        )
        last_time_activities = state_activities.get()
        if last_time_activities is None:
            logging.info("The last time point is not available in activities!")
            links = self._data_table_not_exist(parameter_activity)
        else:
            logging.info(
                "The last time point is available in activities: {}".format(
                    last_time_activities
                )
            )
            links = self._data_table_exist(parameter_activity, last_time_activities)
        list_data = {
            "links": links,
            "state_activities": state_activities,
            "armis_activities": armis_activities,
        }
        return list_data


class AzureSentinel:

    # Build the API signature
    def build_signature(
        self,
        customer_id,
        shared_key,
        date,
        content_length,
        method,
        content_type,
        resource,
    ):
        x_headers = "x-ms-date:" + date
        string_to_hash = (
            method
            + "\n"
            + str(content_length)
            + "\n"
            + content_type
            + "\n"
            + x_headers
            + "\n"
            + resource
        )
        bytes_to_hash = bytes(string_to_hash, encoding="utf-8")
        decoded_key = base64.b64decode(shared_key)
        encoded_hash = base64.b64encode(
            hmac.new(decoded_key, bytes_to_hash, digestmod=hashlib.sha256).digest()
        ).decode()
        authorization = "SharedKey {}:{}".format(customer_id, encoded_hash)
        return authorization

    # Build and send a request to the POST API
    def post_data(self, customer_id, shared_key, body, log_type):
        method = "POST"
        content_type = "application/json"
        resource = "/api/logs"
        rfc1123date = datetime.datetime.utcnow().strftime("%a, %d %b %Y %H:%M:%S GMT")
        content_length = len(body)
        signature = self.build_signature(
            customer_id,
            shared_key,
            rfc1123date,
            content_length,
            method,
            content_type,
            resource,
        )
        uri = (
            "https://"
            + customer_id
            + ".ods.opinsights.azure.com"
            + resource
            + "?api-version=2016-04-01"
        )

        headers = {
            "content-type": content_type,
            "Authorization": signature,
            "Log-Type": log_type,
            "x-ms-date": rfc1123date,
        }

        response = requests.post(uri, data=body, headers=headers)
        if response.status_code >= 200 and response.status_code <= 299:
            logging.info("Accepted : Data Posted Successfully to azure setninel.")
        else:
            logging.error("Response code: {}".format(response.status_code))
            logging.error(response.content)

    def post(self):
        while True:
            if not result_queue.empty():
                required_data_list = result_queue.get()
                table_name = required_data_list["table_name"]
                state = required_data_list["state"]
                body = required_data_list["body"]
                current_time = required_data_list["current_time"]
                self.post_data(customer_id, shared_key, body, table_name)
                state.post(str(current_time))
                time.sleep(2)
                if result_queue.empty():
                    break


def main(mytimer: func.TimerRequest) -> None:
    utc_timestamp = (
        datetime.datetime.utcnow().replace(tzinfo=datetime.timezone.utc).isoformat()
    )
    armis_obj = Armis()
    list_data = armis_obj.check_data_exists_or_not()
    if list_data["links"] is not None:
        fetch_thread = Thread(target=armis_obj.fetch_data, args=(list_data,))
        fetch_thread.start()
        time.sleep(5)
        azuresentinel = AzureSentinel()
        post_thread = Thread(target=azuresentinel.post)
        post_thread.start()
        fetch_thread.join()
        post_thread.join()

    if mytimer.past_due:
        logging.info("The timer is past due!")

    logging.info("Python timer trigger function ran at %s", utc_timestamp)
